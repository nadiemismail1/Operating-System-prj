#ifndef LOGGER_H
#define LOGGER_H

// GUI hook function pointers
extern void (*add_event_gui_message)(const char* msg);
extern void (*add_log_gui_message)(const char* msg);

// Console fallback loggers
void log_event(const char* format, ...);
void log_execution(const char* format, ...);

#endif

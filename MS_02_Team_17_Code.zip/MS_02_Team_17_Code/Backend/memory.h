// memory.h
#ifndef MEMORY_H
#define MEMORY_H

#define MEMORY_SIZE 60

typedef struct {
    char content[100];
} MemoryWord;

extern MemoryWord memory[MEMORY_SIZE];
void storeVariableToMemory(const char* varName, const char* value);

void initializeMemory();
int allocateMemory(int size);
void writeToMemory(int address, const char* data);
const char* readFromMemory(int address);
void resetMemory();

#endif

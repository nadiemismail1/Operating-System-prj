#include "logger.h"
#include <stdio.h>
#include <stdarg.h>

// Function pointer implementations (initialized elsewhere)
void (*add_event_gui_message)(const char* msg) = NULL;
void (*add_log_gui_message)(const char* msg) = NULL;

void log_execution(const char* format, ...) {
    va_list args;
    va_start(args, format);
    if (add_log_gui_message) {
        char buffer[512];
        vsnprintf(buffer, sizeof(buffer), format, args);
        add_log_gui_message(buffer);
    } else {
        printf("[DEBUG] ");
        vprintf(format, args);
        printf("\n");
    }
    va_end(args);
}

void log_event(const char* format, ...) {
    va_list args;
    va_start(args, format);
    if (add_event_gui_message) {
        char buffer[512];
        vsnprintf(buffer, sizeof(buffer), format, args);
        add_event_gui_message(buffer);
    } else {
        printf("[EVENT] ");
        vprintf(format, args);
        printf("\n");
    }
    va_end(args);
}

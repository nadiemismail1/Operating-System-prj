// mutex.h
#ifndef MUTEX_H
#define MUTEX_H

#include "pcb.h"

// Node for processes waiting on a mutex
typedef struct WaitNode { PCB* process; struct WaitNode* next; } WaitNode;

typedef struct {
    int locked;
    int ownerPID;
    WaitNode* waitList;  // list of blocked processes
} Mutex;

extern Mutex userInputMutex, userOutputMutex, fileMutex;

void semWait(Mutex* mutex, PCB* process);
void semSignal(Mutex* mutex);

#endif

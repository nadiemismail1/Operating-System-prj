// pcb.c
#include "pcb.h"
#include <stdio.h>
#include "logger.h"
#include "globals.h"

PCB createPCB(int pid, int lower, int upper) {
    PCB pcb;
    pcb.pid = pid;
    pcb.state = NEW;
    pcb.priority = 1;
    pcb.programCounter = lower;
    pcb.lowerBound = lower;
    pcb.upperBound = upper;
    pcb.quantumUsed = 0;
    pcb.mlfqTicksUsed = 0;
    pcb.mlfqLevel = 1;  // Initialize at level 1 (highest priority)
    pcb.justUnblocked = false;
    pcb.waitTime = 0;
    pcb.blockTime = 0;
    pcb.lastStateChangeTime = clockCycle;
 
    for (int i = 0; i < 26; i++) {
        pcb.variables[i][0] = '\0';
    }

    return pcb;
}


void updatePCBState(PCB* pcb, ProcessState state) {
   // log_execution("Updating process %d state: %d -> %d", pcb->pid, pcb->state, state);

    // Update time spent in previous state
    int timeInState = clockCycle - pcb->lastStateChangeTime;
    
    if (pcb->state == READY) {
        pcb->waitTime += timeInState;
    } else if (pcb->state == BLOCKED) {
        pcb->blockTime += timeInState;
    }
    
    // Update state and reset state change time
    pcb->state = state;
    pcb->lastStateChangeTime = clockCycle;
}

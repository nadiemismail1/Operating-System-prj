// memory.c
#include "memory.h"
#include <string.h>
#include "logger.h"

MemoryWord memory[MEMORY_SIZE];

void initializeMemory() {
    for (int i = 0; i < MEMORY_SIZE; i++) {
        strcpy(memory[i].content, "EMPTY");
    }
}

int allocateMemory(int size) {
    for (int i = 0; i <= MEMORY_SIZE - size; i++) {
        int free = 1;
        for (int j = i; j < i + size; j++) {
            if (strcmp(memory[j].content, "EMPTY") != 0) {
                free = 0;
                break;
            }
        }
        if (free) return i;
    }
    return -1; // No enough memory
}

void writeToMemory(int address, const char* data) {
    strcpy(memory[address].content, data);
}

const char* readFromMemory(int address) {
    return memory[address].content;
}
#include <stdio.h>

void storeVariableToMemory(const char* varName, const char* value) {
    for (int i = 0; i < MEMORY_SIZE; i++) {
        if (strcmp(memory[i].content, "EMPTY") == 0) {
            snprintf(memory[i].content, sizeof(memory[i].content), "%s=%s", varName, value);
            break;
        }
    }
}

void resetMemory() {
    // Reset memory by calling initializeMemory
    initializeMemory();
}

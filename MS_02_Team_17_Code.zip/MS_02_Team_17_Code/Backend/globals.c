#include "globals.h"

int clockCycle = 0;
int processCount = 0;
int arrivalTimes[100];
PCB processes[100];

char userInputA[100] = "";
char userInputB[100] = "";
bool inputReady = false;  

int processWaitingForInput = -1; // No process waiting initially
char inputVariableName[10] = ""; // Empty variable name
bool waitingForInput = false;    // Not waiting for input initially

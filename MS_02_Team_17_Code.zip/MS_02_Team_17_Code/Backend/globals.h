#ifndef GLOBALS_H
#define GLOBALS_H

#include "pcb.h"
#include <stdbool.h> 

extern int clockCycle;
extern int processCount;
extern int arrivalTimes[100];
extern PCB processes[100];

extern char userInputA[100];
extern char userInputB[100];
extern bool inputReady;

extern int processWaitingForInput; // PID of process waiting for input, -1 if none
extern char inputVariableName[10]; // Variable name for the input (a or b)
extern bool waitingForInput;       // Flag indicating we're in input-waiting mode

#endif

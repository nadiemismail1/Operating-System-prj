#ifndef PCB_H
#define PCB_H
#include <stdbool.h>

typedef enum { NEW, READY, RUNNING, BLOCKED, TERMINATED } ProcessState;

typedef struct {
    int pid;
    ProcessState state;
    int priority;
    int programCounter;
    int lowerBound;
    int upperBound;
    char variables[26][100]; // Array for variables a-z
    int quantumUsed;         // For Round Robin
    int mlfqTicksUsed;       // MLFQ-specific quantum tracker
    int mlfqLevel;           // Track the MLFQ level of each process
    bool justUnblocked;
    int waitTime;            // Time spent in READY state
    int blockTime;           // Time spent in BLOCKED state
    int lastStateChangeTime; // Clock cycle when last state change occurred

} PCB;

PCB createPCB(int pid, int lower, int upper);
void updatePCBState(PCB* pcb, ProcessState state);

#endif
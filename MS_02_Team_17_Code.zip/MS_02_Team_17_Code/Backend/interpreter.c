// interpreter.c
#include "interpreter.h"
#include "memory.h"
#include "mutex.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pcb.h"
#include "logger.h"
#include "globals.h"
#include <stdbool.h>
#include "scheduler.h"


void interpretInstruction(PCB* process, const char* instruction);
void loadProgram(const char* filename, int pid) {
// processes[i].quantumUsed = 0;

    FILE* file = fopen(filename, "r");
    if (!file) {
        log_event("Error loading program %s", filename);
        return;
    }
    
    char line[100];
    int base = allocateMemory(20); 
    if (base == -1) {
        log_event("Memory full!");
        fclose(file);
        return;
    }

    processes[processCount] = createPCB(pid, base, base + 19);
    processes[processCount].quantumUsed = 0;

    processCount++;

    int i = base;
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = '\0'; // remove newline
        writeToMemory(i++, line);
    }

    fclose(file);
}

void interpret(PCB *p) {
    // Check if the program counter is within bounds
    if (p->programCounter <= p->upperBound) {
        const char* instruction = readFromMemory(p->programCounter);
        if (strcmp(instruction, "EMPTY") != 0) {
            interpretInstruction(p, instruction);
        }
    }
}

void interpretInstruction(PCB* process, const char* instruction) {
    char command[20], arg1[20], arg2[20];
    sscanf(instruction, "%s %s %s", command, arg1, arg2);

    
    // Special check for input assignment before proceeding
    if (strcmp(command, "assign") == 0 && strcmp(arg2, "input") == 0) {
        // Check if input was already processed        // by on_send_input_clicked (we'll know this because waitingForInput will be false)
        if (!waitingForInput && inputReady) {
        //    log_execution("Input was already processed for process %d", process->pid);
            inputReady = false; // Reset input flag
            return;
        }
        
        // Check if input is already waiting (from Send Input button)
        if (inputReady) {
            // Process the input immediately
            char value[100];
            if (arg1[0] == 'a') {
                strcpy(value, userInputA);
            } else if (arg1[0] == 'b') {
                strcpy(value, userInputB);
            } else {
                log_event("Unsupported input variable: %s", arg1);
                return;
            }

            log_event("Process %d: Received input for %s = %s", process->pid, arg1, value);
            int index = arg1[0] - 'a';
            if (index >= 0 && index < 26) {
                strcpy(process->variables[index], value);
            }
            log_execution("Assigned %s = %s", arg1, value);
            inputReady = false; // Reset input flag after use
        } else {
            // Set up waiting state without blocking
            log_event("Process %d needs input for variable %s. Please enter it and press 'Send Input'.", 
                    process->pid, arg1);
            
            // Store information about which process and variable needs input
            processWaitingForInput = process->pid;
            strncpy(inputVariableName, arg1, sizeof(inputVariableName) - 1);
            waitingForInput = true;
            
            // Don't increment PC - we'll stay on this instruction
            process->programCounter--; // This will be incremented by the scheduler after
        }
        
        return; // Important: return here after handling input
    }
    
    // Rest of the instruction handling
    if (strcmp(command, "assign") == 0) {
        if (strncmp(arg2, "readFile", 8) == 0) {
            // Get the third argument (the filename variable)
            char arg3[20];
            sscanf(instruction, "%s %s %s %s", command, arg1, arg2, arg3);
        
            // Resolve filename from variable 'a'
            char filename[100];
            int fileIndex = arg3[0] - 'a';
            if (fileIndex >= 0 && fileIndex < 26 && process->variables[fileIndex][0] != '\0') {
                strcpy(filename, process->variables[fileIndex]);
                log_execution("Reading file with name from variable %s = %s", arg3, filename);
            } else {
                strcpy(filename, arg3);
                log_execution("Reading file with literal name: %s", filename);
            }
        
            FILE* f = fopen(filename, "r");
            char content[100] = "FILE_ERR";
            if (f) {
                fgets(content, sizeof(content), f);
                content[strcspn(content, "\n")] = '\0';
                fclose(f);
                log_execution("Successfully read file %s: %s", filename, content);
            } else {
                log_event("Error: Could not open file %s", filename);
            }
        
            int varIndex = arg1[0] - 'a';
            if (varIndex >= 0 && varIndex < 26) {
                strcpy(process->variables[varIndex], content);
                log_execution("Assigned %s = %s", arg1, content);
            }
        }
        else {
            // Normal assignment: assign x y
            int index = arg1[0] - 'a';
            if (index >= 0 && index < 26) {
                strcpy(process->variables[index], arg2);
            }
            log_execution("Assigned %s = %s", arg1, arg2);
        }
    }
    else if (strcmp(command, "print") == 0) {
        int index = arg1[0] - 'a';
        if (index >= 0 && index < 26) {
            if (process->variables[index][0] != '\0') {
                log_event("Process %d prints: %s", process->pid, process->variables[index]);
                log_execution("Printing value of variable %s = %s", arg1, process->variables[index]);
            } else {
                log_event("Process %d prints: (empty)", process->pid);
                log_execution("Variable %s is empty", arg1);
            }
        } else {
            log_event("Process %d prints: %s", process->pid, arg1);
            log_execution("Printing literal value: %s", arg1);
        }
    }
    else if (strcmp(command, "end") == 0) {
        log_execution("Process %d completed execution.", process->pid);
        updatePCBState(process, TERMINATED);
    }
    else if (strcmp(command, "writeFile") == 0) {
        // Get values from variable table
        char filename[100], content[100];
        int index1 = arg1[0] - 'a';
        int index2 = arg2[0] - 'a';
        
        // Get filename from variable table if it's a variable
        if (index1 >= 0 && index1 < 26 && process->variables[index1][0] != '\0') {
            strcpy(filename, process->variables[index1]);
        } else {
            strcpy(filename, arg1);
        }
        
        // Get content from variable table if it's a variable
        if (index2 >= 0 && index2 < 26 && process->variables[index2][0] != '\0') {
            strcpy(content, process->variables[index2]);
        } else {
            strcpy(content, arg2);
        }
        
        FILE* f = fopen(filename, "w");
        fprintf(f, "%s\n", content);
        fclose(f);
        log_execution("Wrote to file %s", filename);
    }
    else if (strcmp(command, "readFile") == 0) {
        // Get filename from variable table or literal
        char filename[100];
        int index = arg1[0] - 'a';

        if (index >= 0 && index < 26 && process->variables[index][0] != '\0') {
            strcpy(filename, process->variables[index]);
        } else {
            strcpy(filename, arg1);
        }

        FILE* f = fopen(filename, "r");
        if (!f) {
            add_event_message("Error: Cannot open file");
            return;
        }

        char content[100] = "";
        char c;
        int i = 0;

        while ((c = fgetc(f)) != EOF && i < sizeof(content) - 1) {
            content[i++] = c;
        }
        content[i] = '\0';
        fclose(f);

        log_execution("Reading file %s: %s", filename, content);

        // Store content in variable 'b' and memory (optional)
        int varIndex = 'b' - 'a';
        strcpy(process->variables[varIndex], content);
        storeVariableToMemory("b", content);
    }
    else if (strcmp(command, "printFromTo") == 0) {
        int start, end;
        int index1 = arg1[0] - 'a';
        int index2 = arg2[0] - 'a';

        if (index1 >= 0 && index1 < 26 && process->variables[index1][0] != '\0') {
            start = atoi(process->variables[index1]);
        } else {
            start = atoi(arg1);
        }

        if (index2 >= 0 && index2 < 26 && process->variables[index2][0] != '\0') {
            end = atoi(process->variables[index2]);
        } else {
            end = atoi(arg2);
        }

        char rangeMsg[256] = "";
        for (int i = start; i <= end; i++) {
            char tmp[10];
            sprintf(tmp, "%d ", i);
            strcat(rangeMsg, tmp);
        }

        log_execution("Process %d prints range: %s", process->pid, rangeMsg);
    }
    else if (strcmp(command, "semWait") == 0) {
        if (strcmp(arg1, "userInput") == 0) {
        //    log_execution("Process %d requesting access to resource 'userInput'", process->pid);
            semWait(&userInputMutex, process);
        }
        else if (strcmp(arg1, "userOutput") == 0) {
          //  log_execution("Process %d requesting access to resource 'userOutput'", process->pid);
            semWait(&userOutputMutex, process);
        }
        else if (strcmp(arg1, "file") == 0) {
        //    log_execution("Process %d requesting access to resource 'file'", process->pid);
            semWait(&fileMutex, process);
        }
    }
    else if (strcmp(command, "semSignal") == 0) {
        if (strcmp(arg1, "userInput") == 0) {
            log_event("Process %d signaling to release resource 'userInput'", process->pid);
            semSignal(&userInputMutex);
        }
        else if (strcmp(arg1, "userOutput") == 0) {
            log_event("Process %d signaling to release resource 'userOutput'", process->pid);
            semSignal(&userOutputMutex);
        }
        else if (strcmp(arg1, "file") == 0) {
            log_event("Process %d signaling to release resource 'file'", process->pid);
            semSignal(&fileMutex);
        }
    }
}

void add_event_message(const char* msg) {
    log_event("%s", msg);
}


#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "pcb.h"

// Node in scheduling queue
typedef struct Node { PCB* process; struct Node* next; } Node;
// Queue of PCBs
typedef struct { Node* front; Node* rear; } Queue;
// Global ready queue for scheduling
extern Queue readyQueue;
// Enqueue helper for scheduler and mutex unblocking
void enqueue(Queue* q, PCB* p);
void priorityBoost();
typedef enum { FCFS, RR, MLFQ } SchedulingAlgorithm;
extern int rrQuantum;    // Round-Robin quantum, set by main via scanf
void init_scheduler(SchedulingAlgorithm alg, int quantum);

void setScheduler(SchedulingAlgorithm algo);
void schedule();
void initializeQueues();
void setRRQuantum(int quantum); // setter for RR quantum at runtime
void unblockWaitingProcesses();
void reset_scheduler_state();
extern Queue blockedQueue;

// New function to update quantum during input processing
void updateQuantumForInput(PCB* process);

// Reset CPU state function
void resetCPU();

// Add this with the other extern declarations
extern const int quanta[];

#endif

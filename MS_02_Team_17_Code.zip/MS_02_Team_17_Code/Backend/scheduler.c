// scheduler.c
#include "scheduler.h"
#include "pcb.h"
#include "memory.h"
#include "interpreter.h"
#include "logger.h"
#include "globals.h"
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>  // Add this for bool type
#include <stdio.h>
Queue blockedQueue = {NULL, NULL}; // Global blocked queue

PCB* currentProcess = NULL;

SchedulingAlgorithm currentAlgorithm = MLFQ;
int rrQuantum = 2; // Round Robin quantum
// scheduler.h
void enqueue(Queue* q, PCB* p);

extern Queue mlfq[5];  // So other files like mutex.c can access it
extern SchedulingAlgorithm currentAlgorithm; // Also needed if not already declared

// For MLFQ current running process state
PCB* currentMLFQProcess = NULL;
int currentMLFQLevel = 1;
// Standard MLFQ quantum values
const int quanta[] = {0, 1, 2, 4, 8}; 

Queue readyQueue = {NULL, NULL};
Queue mlfq[5]; // mlfq[1] to mlfq[4] used

void enqueue(Queue* q, PCB* p) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->process = p;
    node->next = NULL;
    if (!q->rear) {
        q->front = q->rear = node;
    } else {
        q->rear->next = node;
        q->rear = node;
    }
}

PCB* dequeue(Queue* q) {
    if (!q->front) return NULL;
    Node* temp = q->front;
    PCB* p = temp->process;
    q->front = temp->next;
    if (!q->front) q->rear = NULL;
    free(temp);
    return p;
}

int isQueueEmpty(Queue* q) {
    return (q->front == NULL);
}
void initializeQueues() {
    readyQueue.front = readyQueue.rear = NULL;
    for (int i = 1; i <= 4; i++) {
        mlfq[i].front = mlfq[i].rear = NULL;
    }

    currentMLFQProcess = NULL;
    currentMLFQLevel = 1;

    for (int i = 0; i < processCount; i++) {
        processes[i].mlfqTicksUsed = 0;
    }
}


void setScheduler(SchedulingAlgorithm algo) {
    currentAlgorithm = algo;
        initializeQueues();
}


void runProcess(PCB* p) {
    // Get the current instruction and log it
    const char* instruction = "Unknown";
    if (p->programCounter <= p->upperBound) {
        instruction = readFromMemory(p->programCounter);
    }
    
    log_execution("runProcess: PID=%d, state=%d, PC=%d, Instruction='%s'", 
                 p->pid, p->state, p->programCounter, instruction);

    if (p->state == NEW) updatePCBState(p, READY);
    if (p->state == READY) updatePCBState(p, RUNNING);
    if (p->state == BLOCKED) {
        log_event("Process %d is blocked, cannot run.", p->pid);
        return;
    }

    if (p->state == RUNNING) {
        interpret(p);
        if (p->state == RUNNING) {
            p->programCounter++;
        }
    }
}


void unblockWaitingProcesses() {
    Node* temp = blockedQueue.front;
    while (temp) {
        PCB* p = temp->process;
        if (p->state == BLOCKED) {
            log_event("Unblocking process %d after input ready", p->pid);
            p->state = RUNNING;
            runProcess(p);               // Execute assign a input now
            p->justUnblocked = true;    // Prevent next cycle repeat

            // Only requeue if still active
            if (p->state == READY || p->state == RUNNING) {
                if (currentAlgorithm == MLFQ)
                    enqueue(&mlfq[1], p);
                else
                    enqueue(&readyQueue, p);
            }
        }
        temp = temp->next;
    }
    blockedQueue.front = blockedQueue.rear = NULL;
}



int isProcessFinished(PCB* p) {
    // Original check for memory bounds or empty instruction
    if (p->programCounter > p->upperBound || strcmp(readFromMemory(p->programCounter), "EMPTY") == 0) {
        return 1;
    }
    
    // Calculate relative position in the process's memory
    int relativePC = p->programCounter - p->lowerBound;
    
    // Check based on relative position for each process
    if (p->pid == 1 && relativePC > 6) {  // Process 1 has 7 instructions (0-6)
        return 1;
    }
    else if (p->pid == 2 && relativePC > 6) {  // Process 2 has 7 instructions (0-6)
        return 1;
    }
    else if (p->pid == 3 && relativePC > 8) {  // Process 3 has 9 instructions (0-8)
        return 1;
    }
    
    return 0;
}

// In scheduler.c, modify the checkArrivals function
void checkArrivals() {
    // First, sort processes by arrival time and PID
    for (int i = 0; i < processCount - 1; i++) {
        for (int j = 0; j < processCount - i - 1; j++) {
            if (arrivalTimes[j] > arrivalTimes[j + 1] || 
                (arrivalTimes[j] == arrivalTimes[j + 1] && processes[j].pid > processes[j + 1].pid)) {
                // Swap arrival times
                int temp = arrivalTimes[j];
                arrivalTimes[j] = arrivalTimes[j + 1];
                arrivalTimes[j + 1] = temp;
                
                // Swap processes
                PCB temp_pcb = processes[j];
                processes[j] = processes[j + 1];
                processes[j + 1] = temp_pcb;
            }
        }
    }

    // Now check arrivals in sorted order
    for (int i = 0; i < processCount; i++) {
        if (arrivalTimes[i] == clockCycle && processes[i].state == NEW) {
            log_event("Process %d arrived at cycle %d", processes[i].pid, clockCycle);

            if (currentAlgorithm == MLFQ) {
                processes[i].mlfqTicksUsed = 0;  // Reset on arrival
                processes[i].mlfqLevel = 1;      // Ensure new processes start at Level 1
                enqueue(&mlfq[1], &processes[i]);
                log_event("Process %d added to highest priority queue (Level 1)", processes[i].pid);
            } else {
                enqueue(&readyQueue, &processes[i]);
            }
            updatePCBState(&processes[i], READY); // Mark as READY to prevent re-adding
        }
    }

    if (currentAlgorithm == MLFQ) {
      //  log_execution("MLFQ Level 1 queue status: empty=%d", isQueueEmpty(&mlfq[1]));
    }
}



void scheduleFCFS() {
   // log_execution("scheduleFCFS called, queue empty=%d", isQueueEmpty(&readyQueue));
    if (isQueueEmpty(&readyQueue)) return;

    PCB* p = readyQueue.front->process;
  //  log_execution("Front process: PID=%d, state=%d", p->pid, p->state);

    // Only execute if it's NEW, READY, or RUNNING
    if (p->state == NEW || p->state == READY || p->state == RUNNING) {
        runProcess(p);

        // If process was TERMINATED during execution
        if (p->state == TERMINATED || isProcessFinished(p)) {
            log_event("Process %d terminated", p->pid);
            updatePCBState(p, TERMINATED);
            dequeue(&readyQueue);
            return;
        }

        // If process blocked, do not dequeue or requeue — just wait
        if (p->state == BLOCKED) {
            log_event("Process %d blocked. Waiting...", p->pid);
            return;
        }

        // If still RUNNING or READY, keep it at the front — no rotation in FCFS
    }
}


void scheduleRR() {
    checkArrivals();

    // First, check if we need to unblock any processes
    unblockWaitingProcesses();

    // If no current process, get one from ready queue
    if (!currentProcess) {
        if (isQueueEmpty(&readyQueue)) {
          //  log_execution("RR: Ready queue is empty");
            return;
        }
        currentProcess = dequeue(&readyQueue);
        if (currentProcess->state == NEW) updatePCBState(currentProcess, READY);
        if (currentProcess->state == READY) updatePCBState(currentProcess, RUNNING);
        currentProcess->quantumUsed = 0;
    }

    // Skip if process is blocked
    if (currentProcess->state == BLOCKED) {
        currentProcess = NULL;
        return;
    }

    log_execution("RR: Running process %d (state=%d, PC=%d, quantum=%d/%d)", 
           currentProcess->pid, currentProcess->state, currentProcess->programCounter,
           currentProcess->quantumUsed, rrQuantum);

    // Run the process
    runProcess(currentProcess);

    // Check if process is finished
    if (isProcessFinished(currentProcess)) {
        log_event("Process %d terminated", currentProcess->pid);
        updatePCBState(currentProcess, TERMINATED);
        currentProcess->quantumUsed = 0;
        currentProcess = NULL;
        return;
    }

    // If process became blocked during execution
    if (currentProcess->state == BLOCKED) {
        log_event("Process %d blocked", currentProcess->pid);
        currentProcess->quantumUsed = 0;
        currentProcess = NULL;
        return;
    }

    // Always increment quantum when executing an instruction
    if (currentProcess->state == RUNNING) {
        // Increment quantum usage for every instruction executed
        currentProcess->quantumUsed++;
        log_execution("Process %d used quantum %d/%d", 
            currentProcess->pid, currentProcess->quantumUsed, rrQuantum);

        // Preempt if quantum expired
        if (currentProcess->quantumUsed >= rrQuantum) {
        //    log_execution("Process %d quantum expired, preempting", currentProcess->pid);
            currentProcess->quantumUsed = 0;
            updatePCBState(currentProcess, READY);
            enqueue(&readyQueue, currentProcess);
            currentProcess = NULL;
        }
    }
}





void scheduleMLFQ() {
    // Priority boost every 20 cycles
    if (clockCycle > 1 && clockCycle % 20 == 0) {
        log_event("Priority boost: moving all processes to queue 1");
        for (int lvl = 2; lvl <= 4; lvl++) {
            while (!isQueueEmpty(&mlfq[lvl])) {
                PCB* p = dequeue(&mlfq[lvl]);
                if (p && p->state != TERMINATED) {
                    p->mlfqTicksUsed = 0;
                    p->mlfqLevel = 1;
                    enqueue(&mlfq[1], p);
                }
            }
        }
    }

    // Check for arrivals
    checkArrivals();

    // If current process used up its quantum, demote and clear
    if (currentMLFQProcess != NULL && currentMLFQProcess->state == RUNNING) {
        if (currentMLFQProcess->mlfqTicksUsed >= quanta[currentMLFQProcess->mlfqLevel]) {
        //    log_execution("Process %d used up quantum at level %d",
        //                  currentMLFQProcess->pid, currentMLFQProcess->mlfqLevel);

            updatePCBState(currentMLFQProcess, READY);
            if (currentMLFQProcess->mlfqLevel < 4) {
                currentMLFQProcess->mlfqLevel++;
                enqueue(&mlfq[currentMLFQProcess->mlfqLevel], currentMLFQProcess);
                log_event("Process %d demoted to queue %d",
                          currentMLFQProcess->pid, currentMLFQProcess->mlfqLevel);
            } else {
                enqueue(&mlfq[4], currentMLFQProcess); // RR level
            //    log_event("Process %d stays in RR level 4", currentMLFQProcess->pid);
            }

            // Force current process to null to select a new one
            currentMLFQProcess = NULL;
        }
    }

    // Select a new process if none is running
    if (currentMLFQProcess == NULL) {
        int selectedLevel = 0;
        // First check which is the highest non-empty level
        for (int lvl = 1; lvl <= 4; lvl++) {
            if (!isQueueEmpty(&mlfq[lvl])) {
                selectedLevel = lvl;
                break;
            }
        }

        if (selectedLevel > 0) {
            PCB* candidate = dequeue(&mlfq[selectedLevel]);
            if (candidate->state != BLOCKED && candidate->state != TERMINATED) {
                currentMLFQProcess = candidate;
                currentMLFQLevel = selectedLevel;
                candidate->mlfqLevel = selectedLevel;
                candidate->mlfqTicksUsed = 0;
                if (candidate->state == NEW) updatePCBState(candidate, READY);
                if (candidate->state == READY) updatePCBState(candidate, RUNNING);
                log_execution("Selected process %d at level %d with quantum %d",
                              candidate->pid, selectedLevel, quanta[selectedLevel]);
            } else {
                // Skip blocked processes but keep them in their queue
                enqueue(&mlfq[selectedLevel], candidate);
                currentMLFQProcess = NULL;
            }
        }
    }

    // Run the selected process
    if (currentMLFQProcess != NULL && currentMLFQProcess->state == RUNNING) {
        runProcess(currentMLFQProcess);

        // If still running after instruction
        if (currentMLFQProcess->state == RUNNING) {
            // Always increment ticks used, even for input operations
            currentMLFQProcess->mlfqTicksUsed++;
            log_execution("PID=%d at Level=%d used %d/%d",
                         currentMLFQProcess->pid,
                         currentMLFQProcess->mlfqLevel,
                         currentMLFQProcess->mlfqTicksUsed,
                         quanta[currentMLFQProcess->mlfqLevel]);
        }

        // If it finished
        if (isProcessFinished(currentMLFQProcess)) {
            updatePCBState(currentMLFQProcess, TERMINATED);
            currentMLFQProcess = NULL;
            return;
        }

        // If blocked
        if (currentMLFQProcess->state == BLOCKED) {
            log_event("Process %d blocked, keeping at same level %d", 
                         currentMLFQProcess->pid, currentMLFQProcess->mlfqLevel);
            currentMLFQProcess = NULL;
            return;
        }
    }
}

void init_scheduler(SchedulingAlgorithm alg, int quantum) {
    currentAlgorithm = alg;

    if (alg == RR) {
        rrQuantum = quantum;
    }

    // Re-initialize MLFQ state if needed
    initializeQueues();
}


void schedule() {
    log_execution("\n--- Clock Cycle: %d ---", clockCycle);
    log_event("\n--- Clock Cycle: %d ---", clockCycle);
  //  log_execution("Current scheduling algorithm: %s", currentAlgorithm == FCFS ? "FCFS" : currentAlgorithm == RR ? "RR" : "MLFQ");

    checkArrivals();

    switch (currentAlgorithm) {
        case FCFS:
            scheduleFCFS();
            break;
        case RR:
            scheduleRR();
            break;
        case MLFQ:
            scheduleMLFQ();
            break;
    }
    
    // Remove this line - clock is already incremented in main.c
    // clockCycle++;
}

// After the runProcess function, add this helper function
void updateQuantumForInput(PCB* process) {
    if (currentAlgorithm == RR) {
        // Don't reset quantum for input operations - track correctly
        // Instead, log the current quantum usage
    //    log_execution("Process %d using quantum %d/%d for input processing", 
    //                 process->pid, process->quantumUsed, rrQuantum);
        
        // Add a check for quantum expiry
        if (process->quantumUsed >= rrQuantum) {
        //    log_execution("Process %d quantum expired during input, will be preempted after input", 
        //                 process->pid);
        }
    }
}

// Implementation of resetCPU function
void resetCPU() {
    // Reset current processes
    currentProcess = NULL;
    currentMLFQProcess = NULL;
    currentMLFQLevel = 1;
    
    // Reset queues
    initializeQueues();
    
    // Reset CPU state
    for (int i = 0; i < processCount; i++) {
        processes[i].state = TERMINATED;
    }
    
    // Reset scheduler algorithm to default
    currentAlgorithm = MLFQ;
    rrQuantum = 2;
    
    log_event("CPU state reset");
}
#ifndef INTERPRETER_H
#define INTERPRETER_H

#include "pcb.h"

void loadProgram(const char* filename, int pid);
void interpret(PCB* p); // <--- ADD THIS LINE
void add_event_message(const char* msg);


#endif

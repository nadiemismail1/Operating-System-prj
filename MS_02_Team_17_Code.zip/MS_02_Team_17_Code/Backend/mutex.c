#include "mutex.h"
#include "scheduler.h"
#include <stdio.h>
#include <stdlib.h>
#include "logger.h"
#include <string.h>
extern Queue mlfq[5];
extern Queue blockedQueue;
extern SchedulingAlgorithm currentAlgorithm;

Mutex userInputMutex = {0, -1, NULL};
Mutex userOutputMutex = {0, -1, NULL};
Mutex fileMutex = {0, -1, NULL};

// Helper function to identify which resource the mutex is for
const char* getResourceName(Mutex* mutex) {
    if (mutex == &userInputMutex) return "userInput";
    if (mutex == &userOutputMutex) return "userOutput";
    if (mutex == &fileMutex) return "file";
    return "unknown";
}

void semWait(Mutex* mutex, PCB* process) {
    const char* resourceName = getResourceName(mutex);
    log_execution("Process %d attempting semWait on resource '%s', mutex locked=%d", 
                 process->pid, resourceName, mutex->locked);
    
    if (!mutex->locked) {
        mutex->locked = 1;
        mutex->ownerPID = process->pid;
        log_execution("Process %d acquired resource '%s'", process->pid, resourceName);
    } else {
        log_event("Process %d BLOCKED waiting for resource '%s'", process->pid, resourceName);
        updatePCBState(process, BLOCKED);

        // Add to mutex waitList
        WaitNode* node = malloc(sizeof(WaitNode));
        node->process = process;
        node->next = NULL;
        if (!mutex->waitList) mutex->waitList = node;
        else {
            WaitNode* t = mutex->waitList;
            while (t->next) t = t->next;
            t->next = node;
        }
    }
}

void semSignal(Mutex* mutex) {
    const char* resourceName = getResourceName(mutex);
    if (mutex->ownerPID != -1) {
        log_execution("Process %d releasing resource '%s'", mutex->ownerPID, resourceName);
    } else {
        log_execution("Resource '%s' being released (no owner)", resourceName);
    }
    
    if (!mutex->waitList) {
        // No waiting processes, just release the lock
        mutex->locked = 0;
        mutex->ownerPID = -1;
        return;
    }

    // Find the highest-priority process in waitList
    WaitNode *prev = NULL, *curr = mutex->waitList;
    WaitNode *bestPrev = NULL, *bestNode = curr;

    while (curr) {
        if (curr->process->mlfqLevel < bestNode->process->mlfqLevel) {
            bestNode = curr;
            bestPrev = prev;
        }
        prev = curr;
        curr = curr->next;
    }

    // Remove bestNode from waitList
    if (bestNode == mutex->waitList) {
        mutex->waitList = bestNode->next;
    } else {
        bestPrev->next = bestNode->next;
    }

    PCB* unblocked = bestNode->process;
    free(bestNode);

    log_execution("Unblocking process %d (priority level %d) waiting for resource '%s'", 
                 unblocked->pid, unblocked->mlfqLevel, resourceName);
    
    // Give the mutex directly to the unblocked process
    mutex->locked = 1;
    mutex->ownerPID = unblocked->pid;
    log_execution("Process %d acquired resource '%s' after being unblocked", 
                 unblocked->pid, resourceName);
    
    // For MLFQ, the process has already used one quantum for the semWait
    // and should consider the quantum complete
    if (currentAlgorithm == MLFQ) {
        // The process used its quantum for the semWait already
        unblocked->mlfqTicksUsed = quanta[unblocked->mlfqLevel];
        
        // Mark it as ready (but don't run it immediately)
        updatePCBState(unblocked, READY);
        
        // Increment PC since the semWait is now complete
        unblocked->programCounter++;
        
        // If it was at Level 1, demote it since it used its quantum
        if (unblocked->mlfqLevel == 1) {
            unblocked->mlfqLevel = 2; // Demote to level 2
            log_event("Process %d demoted to level 2 after unblocking", unblocked->pid);
            enqueue(&mlfq[2], unblocked);
        } else {
            // Otherwise, just enqueue to its current level
            enqueue(&mlfq[unblocked->mlfqLevel], unblocked);
        }
    } else {
        // For FCFS and RR
        updatePCBState(unblocked, READY);
        unblocked->programCounter++; // Move past the semWait
        enqueue(&readyQueue, unblocked);
    }
}

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <glib.h>

#include "../Backend/memory.h"
#include "../Backend/interpreter.h"
#include "../Backend/pcb.h"
#include "../Backend/scheduler.h"
#include "../Backend/mutex.h"
#include "../Backend/globals.h"
#include "../Backend/logger.h"

// External declarations for scheduler
extern SchedulingAlgorithm currentAlgorithm;
extern PCB* currentProcess;
extern PCB* currentMLFQProcess;
extern Queue mlfq[5];
extern const int quanta[];

// Function to append messages to the Event Log
void append_event_message(const char *message) {
    // Simply call add_event_gui_message which is already properly implemented
    add_event_gui_message(message);
}


GtkWidget *window;
GtkWidget *process_table;
GtkWidget *log_textview;
GtkWidget *event_textview;
guint auto_timeout_id = 0;
static GtkWidget *arrival_time_entry;
static GtkWidget *input_a_entry;
static GtkWidget *input_b_entry;
static GtkWidget *send_input_btn;
static GtkWidget *overview_label;
static GtkWidget *ready_queue, *blocked_queue, *running_process_label;
static GtkWidget *algorithm_dropdown, *quantum_field, *start_btn, *stop_btn, *reset_btn, *step_btn, *auto_btn;
static GtkWidget *user_input_mutex, *user_output_mutex, *file_mutex;
static GtkWidget *user_input_blocked, *user_output_blocked, *file_blocked;
static GtkWidget *memory_grid, *add_process_btn;
static GtkWidget *memory_labels[60];
static GtkTextBuffer *log_buffer, *event_buffer;

static gboolean running = FALSE;

static int next_pid = 1;




// Function prototypes
void update_ui();
gboolean auto_step_callback(gpointer data);
// Forward declarations
void on_step_clicked(GtkWidget *widget, gpointer data);
void on_stop_clicked(GtkWidget *widget, gpointer data);
void on_reset_clicked(GtkWidget *widget, gpointer data);

// GTK log callback implementations
void gui_log_message(const char* msg) {
    GtkTextBuffer* buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(log_textview));
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    gtk_text_buffer_insert(buffer, &end, msg, -1);
    gtk_text_buffer_insert(buffer, &end, "\n", -1);
    
    // Make sure the view scrolls to show the new text
    gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(log_textview), &end, 0.0, FALSE, 0.0, 0.0);
    
    // Process pending events to update the UI immediately
    while (gtk_events_pending())
        gtk_main_iteration();
}

void gui_event_message(const char* msg) {
    GtkTextBuffer* buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(event_textview));
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    gtk_text_buffer_insert(buffer, &end, msg, -1);
    gtk_text_buffer_insert(buffer, &end, "\n", -1);
    
    // Make sure the view scrolls to show the new text
    gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(event_textview), &end, 0.0, FALSE, 0.0, 0.0);
    
    // Process pending events to update the UI immediately
    while (gtk_events_pending())
        gtk_main_iteration();
}

// Callback implementations
void stop_auto_mode() {
    if (auto_timeout_id != 0) {
        g_source_remove(auto_timeout_id);
        auto_timeout_id = 0;
    }
}

void on_add_process_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *dialog = gtk_file_chooser_dialog_new("Select Process File",
                                                   GTK_WINDOW(window),
                                                   GTK_FILE_CHOOSER_ACTION_OPEN,
                                                   "_Cancel", GTK_RESPONSE_CANCEL,
                                                   "_Open", GTK_RESPONSE_ACCEPT,
                                                   NULL);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
        char *filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));

        // Extract program number from filename
        int program_number = 0;
        char *program_str = strstr(filename, "Program_");
        if (program_str) {
            program_number = atoi(program_str + 8); // Skip "Program_" prefix
        }
        
        if (program_number == 0) {
            append_event_message("Error: Invalid program filename. Must be in format 'Program_X.txt'");
            g_free(filename);
            gtk_widget_destroy(dialog);
            return;
        }

        // Use the existing arrival time entry field
        const char *arrival_text = gtk_entry_get_text(GTK_ENTRY(arrival_time_entry));
        int arrival = atoi(arrival_text);
        
        if (arrival < clockCycle) {
            arrival = clockCycle;
            char buffer[32];
            sprintf(buffer, "%d", arrival);
            gtk_entry_set_text(GTK_ENTRY(arrival_time_entry), buffer);
        }

        if (next_pid == 1) {
            append_event_message("Initializing memory before loading first process...");
            initializeMemory();
        }

        // Load program into memory
        char debug_msg[256];
        sprintf(debug_msg, "Attempting to load program: %s with PID: %d, Arrival: %d", 
                filename, program_number, arrival);
        append_event_message(debug_msg);

        // First load the program (uses only 2 parameters)
        loadProgram(filename, program_number);
        
        // Then set arrival time separately
        int process_index = processCount - 1;
        arrivalTimes[process_index] = arrival;

        char msg[256];
        sprintf(msg, "Program loaded to memory. PID=%d, Arrival=%d, ProcessCount=%d", 
                program_number, arrival, processCount);
        append_event_message(msg);

        next_pid = program_number + 1;  // Update next_pid to be after the highest program number
        update_ui();
        
        // Show process table
        gtk_widget_show_all(process_table);

        g_free(filename);
    }

    gtk_widget_destroy(dialog);
}



void on_start_clicked(GtkWidget *widget, gpointer data) {
    add_event_gui_message("Start button clicked");
    
    if (!running) {
        running = TRUE;
        add_event_gui_message("Simulation set to running state");

        // Get selected algorithm from dropdown
        const gchar *algorithm_text = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algorithm_dropdown));
        add_event_gui_message(g_strdup_printf("Selected algorithm: %s", algorithm_text));
        
        SchedulingAlgorithm selected_alg;

        if (g_strcmp0(algorithm_text, "First Come First Serve") == 0)
            selected_alg = FCFS;
        else if (g_strcmp0(algorithm_text, "Round Robin") == 0)
            selected_alg = RR;
        else if (g_strcmp0(algorithm_text, "Multi-Level Feedback Queue") == 0)
            selected_alg = MLFQ;
        else {
            add_event_gui_message("Invalid scheduling algorithm selected");
            return;
        }

        // Get quantum (only for RR)
        int quantum_value = 0;
        if (selected_alg == RR) {
            const gchar *quantum_text = gtk_entry_get_text(GTK_ENTRY(quantum_field));
            quantum_value = atoi(quantum_text);
            add_event_gui_message(g_strdup_printf("Quantum value: %d", quantum_value));
            add_event_gui_message(g_strdup_printf("Final quantum passed to backend: %d", quantum_value));

            
            if (quantum_value <= 0) {
                quantum_value = 3;  // Default quantum
                add_event_gui_message("Invalid quantum value. Using default quantum of 3");
            }
        }

        // Initialize scheduler
        add_event_gui_message("Initializing scheduler...");
        initializeQueues();     // Sets up ready queues
        init_scheduler(selected_alg, quantum_value);
        
        // Make sure existing processes are properly initialized
        for (int i = 0; i < processCount; i++) {
            // Reset any process that might be in an inconsistent state
            if (processes[i].state != TERMINATED) {
                processes[i].programCounter = processes[i].lowerBound;
                processes[i].quantumUsed = 0;
                processes[i].mlfqTicksUsed = 0;
                processes[i].mlfqLevel = 1;
                
                // Mark as NEW to ensure it gets picked up by checkArrivals
                updatePCBState(&processes[i], NEW);
                
                add_event_gui_message(g_strdup_printf("Reset process %d state to NEW", processes[i].pid));
            }
        }

        // Update UI
        char msg[100];
        if (selected_alg == RR) {
            sprintf(msg, "Simulation started with Round Robin (quantum=%d)", quantum_value);
        } else {
            sprintf(msg, "Simulation started with %s", 
                   (selected_alg == FCFS) ? "FCFS" : "MLFQ");
        }
        add_event_gui_message(msg);
        update_ui();
        add_event_gui_message("UI updated. Simulation ready.");
        
        // Trigger the first step
        on_step_clicked(NULL, NULL);
    } else {
        add_event_gui_message("Simulation already running");
    }
}


void on_reset_clicked(GtkWidget *widget, gpointer data) {
    add_event_gui_message("Reset button clicked");
    
    // Stop auto mode if running
    on_stop_clicked(NULL, NULL);

    // Reset all state
    resetCPU();
    resetMemory();
    
    processCount = 0;
    clockCycle = 0;
    next_pid = 1;
    inputReady = false;
    waitingForInput = false;
    processWaitingForInput = -1;
    strcpy(inputVariableName, "");
    memset(userInputA, 0, sizeof(userInputA));
    memset(userInputB, 0, sizeof(userInputB));
    
    // Reset scheduler and blocked queues
    if (currentAlgorithm == MLFQ) {
        for (int i = 1; i <= 4; i++) {
            mlfq[i].front = mlfq[i].rear = NULL;
        }
    } else {
        readyQueue.front = readyQueue.rear = NULL;
    }
    blockedQueue.front = blockedQueue.rear = NULL;
    
    // Reset mutexes
    userInputMutex.locked = 0;
    userInputMutex.ownerPID = -1;
    // Free wait list for userInputMutex
    WaitNode* node = userInputMutex.waitList;
    while (node) {
        WaitNode* temp = node;
        node = node->next;
        free(temp);
    }
    userInputMutex.waitList = NULL;
    
    userOutputMutex.locked = 0;
    userOutputMutex.ownerPID = -1;
    // Free wait list for userOutputMutex
    node = userOutputMutex.waitList;
    while (node) {
        WaitNode* temp = node;
        node = node->next;
        free(temp);
    }
    userOutputMutex.waitList = NULL;
    
    fileMutex.locked = 0;
    fileMutex.ownerPID = -1;
    // Free wait list for fileMutex
    node = fileMutex.waitList;
    while (node) {
        WaitNode* temp = node;
        node = node->next;
        free(temp);
    }
    fileMutex.waitList = NULL;
    
    // Clear process table UI
    GList *children = gtk_container_get_children(GTK_CONTAINER(process_table));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    // Clear ready queue UI
    children = gtk_container_get_children(GTK_CONTAINER(ready_queue));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    // Clear blocked queue UI
    children = gtk_container_get_children(GTK_CONTAINER(blocked_queue));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    // Clear resource-specific blocked queues UI
    children = gtk_container_get_children(GTK_CONTAINER(user_input_blocked));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    children = gtk_container_get_children(GTK_CONTAINER(user_output_blocked));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    children = gtk_container_get_children(GTK_CONTAINER(file_blocked));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    // Clear running process
    gtk_label_set_text(GTK_LABEL(running_process_label), "Running: None");
    
    // Clear log and event buffers
    gtk_text_buffer_set_text(log_buffer, "", -1);
    gtk_text_buffer_set_text(event_buffer, "", -1);

    add_event_gui_message("System reset");
    update_ui();
    
    // Make all UI elements visible
    gtk_widget_show_all(process_table);
}

void on_algorithm_changed(GtkComboBox *widget, gpointer user_data) {
    const gchar *algorithm_text = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(widget));
    
    if (g_strcmp0(algorithm_text, "Round Robin") == 0) {
        gtk_widget_set_sensitive(quantum_field, TRUE);
        gtk_entry_set_text(GTK_ENTRY(quantum_field), "");  // Clear the field for user input
    } else {
        gtk_widget_set_sensitive(quantum_field, FALSE);
        gtk_entry_set_text(GTK_ENTRY(quantum_field), "");  // Clear for FCFS/MLFQ
    }
}


void on_quantum_changed(GtkEntry *entry, gpointer data) {
    const gchar *quantum_text = gtk_entry_get_text(entry);
    int new_quantum = atoi(quantum_text);
    
    if (new_quantum <= 0) {
        new_quantum = 3;  // Default quantum
        gtk_entry_set_text(entry, "3");
        add_event_gui_message("Invalid quantum value. Using default quantum of 3");
    } else {
        add_event_gui_message(g_strdup_printf("Quantum set to %d", new_quantum));
    }

    // ✅ FIX: Get the selected algorithm
    int selected_alg = gtk_combo_box_get_active(GTK_COMBO_BOX(algorithm_dropdown));
}


void update_overview() {
    char overview_text[256];
    const gchar *algorithm = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algorithm_dropdown));
    
    snprintf(overview_text, sizeof(overview_text),
             "System Overview\n"
             "Total Processes: %d\n"
             "Clock Cycle: %d\n"
             "Algorithm: %s",
             processCount, 
             clockCycle, 
             algorithm);
             
    gtk_label_set_text(GTK_LABEL(overview_label), overview_text);
}



void on_step_clicked(GtkWidget *widget, gpointer data) {
   // add_event_gui_message(g_strdup_printf("Step button clicked - Current cycle: %d", clockCycle));
    
    schedule();      // Run the scheduler (already includes checkArrivals)
    clockCycle++;    // Move to next cycle
    
    add_event_gui_message(g_strdup_printf("After scheduler - Process count: %d", processCount));
    
    update_ui();     // Refresh frontend
    
    // Make sure UI elements are visible - sometimes they can be hidden
    gtk_widget_show_all(process_table);
}


gboolean auto_step_callback(gpointer data) {
    if (!running) {
        g_print("Stopping auto-step: running is FALSE\n");
        return FALSE;  // Stop if user hit Stop
    }

    g_print("Auto-step: clockCycle = %d\n", clockCycle);
    schedule();
    clockCycle++;
    update_ui();
    return TRUE;  // Keep running
}

void on_auto_clicked(GtkWidget *widget, gpointer data) {
    if (!running) {
        g_print("Starting auto-step\n");
        running = TRUE;
        auto_timeout_id = g_timeout_add(250, auto_step_callback, NULL);
        if (auto_timeout_id == 0) {
            g_print("Error: Failed to add timeout\n");
        }
    }
}

void on_stop_clicked(GtkWidget *widget, gpointer data) {
    if (running) {
        g_print("Stopping auto-step\n");
        running = FALSE;
        if (auto_timeout_id != 0) {
            g_source_remove(auto_timeout_id);
            auto_timeout_id = 0;
        }
    }
}

void on_send_input_clicked(GtkButton *button, gpointer user_data) {
    const char *inputA = gtk_entry_get_text(GTK_ENTRY(input_a_entry));
    const char *inputB = gtk_entry_get_text(GTK_ENTRY(input_b_entry));

    strncpy(userInputA, inputA, sizeof(userInputA) - 1);
    strncpy(userInputB, inputB, sizeof(userInputB) - 1);
    
    // Make sure strings are null-terminated
    userInputA[sizeof(userInputA) - 1] = '\0';
    userInputB[sizeof(userInputB) - 1] = '\0';
    
    add_event_gui_message("Inputs received and stored.");
    
    // If we have a specific process waiting for input
    if (waitingForInput && processWaitingForInput != -1) {
        char message[100];
        sprintf(message, "Input provided for process %d, variable %s", 
                processWaitingForInput, inputVariableName);
        add_event_gui_message(message);
        
        // Find the process that is waiting for input
        PCB* processToUpdate = NULL;
        for (int i = 0; i < processCount; i++) {
            if (processes[i].pid == processWaitingForInput) {
                processToUpdate = &processes[i];
                break;
            }
        }
        
        if (processToUpdate) {
            // Apply input directly to the process's variable
            char value[100];
            if (inputVariableName[0] == 'a') {
                strcpy(value, userInputA);
            } else if (inputVariableName[0] == 'b') {
                strcpy(value, userInputB);
            } else {
                add_event_gui_message("Error: Invalid variable name");
                return;
            }
            
            // Store the value in the process's variable table
            int index = inputVariableName[0] - 'a';
            if (index >= 0 && index < 26) {
                strcpy(processToUpdate->variables[index], value);
                log_event("Process %d: Received input for %s = %s", processToUpdate->pid, inputVariableName, value);
                log_execution("Assigned %s = %s", inputVariableName, value);
            }
            
            // Update quantum tracking for this instruction
            updateQuantumForInput(processToUpdate);
            
            // Increment the program counter to avoid re-executing the input instruction
            processToUpdate->programCounter++;
            
            // Reset waiting flags
            waitingForInput = false;
            processWaitingForInput = -1;
            
            // Update UI
            update_ui();
        }
    } else {
        // Traditional behavior - set input ready and unblock processes
        inputReady = true;
        unblockWaitingProcesses();
    }
    
    // Advance the simulation
    on_step_clicked(NULL, NULL);
}




// UI Update functions
void update_ui() {
    log_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(log_textview));

    //add_event_gui_message(g_strdup_printf("Updating UI - Process count: %d", processCount));

    // Update overview section first
    update_overview();

    // Update process table using GtkListBox
    if (GTK_IS_LIST_BOX(process_table)) {
        // Get all rows from the process table
        GList *children = gtk_container_get_children(GTK_CONTAINER(process_table));
        int row_count = g_list_length(children);
        
       // add_event_gui_message(g_strdup_printf("Process table row count: %d", row_count));
        
        // Skip the first row (header) and remove only process rows
        if (row_count > 1) {
            GList *processRows = g_list_next(children); // Skip header row
            while (processRows) {
                GtkWidget *row = processRows->data;
                gtk_widget_destroy(row);
                processRows = g_list_next(processRows);
            }
        } else {
            // If no header exists or all rows were removed, add the header
            GtkWidget *header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
            gtk_widget_set_margin_start(header, 5);
            gtk_widget_set_margin_end(header, 5);
            gtk_widget_set_margin_top(header, 5);
            
          //  add_event_gui_message("Adding new header row to process table");
            
            // Define column widths
            const int column_widths[] = {100, 100, 100, 100, 100}; // Same as elsewhere
            const char *column_titles[] = {"Process ID", "State", "Priority", "PC", "Memory"};
            
            for (int i = 0; i < 5; i++) {
                GtkWidget *label = gtk_label_new(column_titles[i]);
                gtk_widget_set_size_request(label, column_widths[i], -1);
                gtk_label_set_xalign(GTK_LABEL(label), 0.5); // Center align text
                gtk_box_pack_start(GTK_BOX(header), label, FALSE, FALSE, 0);
            }
            
            gtk_list_box_insert(GTK_LIST_BOX(process_table), header, 0);
        }
        
        g_list_free(children);
        
        // Add real processes from the backend
   //     add_event_gui_message(g_strdup_printf("Adding %d processes to table", processCount));

        // Define column widths (same as in create_process_table)
        const int column_widths[] = {100, 100, 100, 100, 100}; 

        for (int i = 0; i < processCount; i++) {
            GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
            gtk_widget_set_margin_start(row, 5);
            gtk_widget_set_margin_end(row, 5);
            
            char state_str[20];
            switch(processes[i].state) {
                case NEW: strcpy(state_str, "New"); break;
                case READY: strcpy(state_str, "Ready"); break;
                case RUNNING: strcpy(state_str, "Running"); break;
                case BLOCKED: strcpy(state_str, "Blocked"); break;
                case TERMINATED: strcpy(state_str, "Terminated"); break;
                default: strcpy(state_str, "Unknown");
            }
            
            add_event_gui_message(g_strdup_printf("Adding process %d with state %s", 
                               processes[i].pid, state_str));
            
            char bounds[30];
            sprintf(bounds, "%d-%d", processes[i].lowerBound, processes[i].upperBound);
            
            // Create properly aligned labels
            GtkWidget *pid_label = gtk_label_new(g_strdup_printf("%d", processes[i].pid));
            GtkWidget *state_label = gtk_label_new(state_str);
            GtkWidget *priority_label = gtk_label_new(g_strdup_printf("%d", processes[i].priority));
            GtkWidget *pc_label = gtk_label_new(g_strdup_printf("0x%04X", processes[i].programCounter));
            GtkWidget *mem_label = gtk_label_new(bounds);
            
            // Store labels in array for easier iteration
            GtkWidget *labels[] = {pid_label, state_label, priority_label, pc_label, mem_label};
            
            // Set alignment for each label
            for (int j = 0; j < 5; j++) {
                gtk_widget_set_size_request(labels[j], column_widths[j], -1);
                gtk_label_set_xalign(GTK_LABEL(labels[j]), 0.5); // Center align
                gtk_box_pack_start(GTK_BOX(row), labels[j], FALSE, FALSE, 0);
            }
            
            gtk_list_box_insert(GTK_LIST_BOX(process_table), row, -1);
        }
        
        // Make sure all processes are visible
        gtk_widget_show_all(process_table);
    } else {
        add_event_gui_message("Warning: Process table is not a GtkListBox");
    }
    
    // Update memory grid - display actual memory contents
    for (int i = 0; i < MEMORY_SIZE && i < 60; i++) {
        if (memory_labels[i] != NULL && GTK_IS_LABEL(memory_labels[i])) {
            gtk_label_set_text(GTK_LABEL(memory_labels[i]), memory[i].content);
        }
    }
    
    // Update ready queue
    GtkListBox *ready_box = GTK_LIST_BOX(ready_queue);
    GList *children = gtk_container_get_children(GTK_CONTAINER(ready_queue));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);

    // Add header to ready queue
    GtkWidget *ready_header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    GtkWidget *pid_label = gtk_label_new("PID");
    GtkWidget *pc_label = gtk_label_new("PC");
    GtkWidget *instr_label = gtk_label_new("Instruction");
    GtkWidget *wait_label = gtk_label_new("Wait Time");

    gtk_widget_set_size_request(pid_label, 60, -1);
    gtk_widget_set_size_request(pc_label, 80, -1);
    gtk_widget_set_size_request(instr_label, 150, -1);
    gtk_widget_set_size_request(wait_label, 80, -1);

    gtk_label_set_xalign(GTK_LABEL(pid_label), 0.5);
    gtk_label_set_xalign(GTK_LABEL(pc_label), 0.5);
    gtk_label_set_xalign(GTK_LABEL(instr_label), 0.5);
    gtk_label_set_xalign(GTK_LABEL(wait_label), 0.5);

    gtk_box_pack_start(GTK_BOX(ready_header), pid_label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(ready_header), pc_label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(ready_header), instr_label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(ready_header), wait_label, FALSE, FALSE, 5);

    gtk_list_box_insert(ready_box, ready_header, -1);

    // Add ready processes
    for (int i = 0; i < processCount; i++) {
        if (processes[i].state == READY) {
            GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
            
            // Get current instruction from memory
            const char* instruction = "Unknown";
            if (processes[i].programCounter <= processes[i].upperBound) {
                instruction = readFromMemory(processes[i].programCounter);
            }
            
            // Use tracked wait time from PCB
            int wait_time = processes[i].waitTime;
            
            // Create labels
            GtkWidget *pid = gtk_label_new(g_strdup_printf("%d", processes[i].pid));
            GtkWidget *pc = gtk_label_new(g_strdup_printf("0x%04X", processes[i].programCounter));
            GtkWidget *instr = gtk_label_new(instruction);
            GtkWidget *wait = gtk_label_new(g_strdup_printf("%d", wait_time));
            
            // Set sizes and alignment
            gtk_widget_set_size_request(pid, 60, -1);
            gtk_widget_set_size_request(pc, 80, -1);
            gtk_widget_set_size_request(instr, 150, -1);
            gtk_widget_set_size_request(wait, 80, -1);
            
            gtk_label_set_xalign(GTK_LABEL(pid), 0.5);
            gtk_label_set_xalign(GTK_LABEL(pc), 0.5);
            gtk_label_set_xalign(GTK_LABEL(instr), 0.5);
            gtk_label_set_xalign(GTK_LABEL(wait), 0.5);
            
            // Pack into row
            gtk_box_pack_start(GTK_BOX(row), pid, FALSE, FALSE, 5);
            gtk_box_pack_start(GTK_BOX(row), pc, FALSE, FALSE, 5);
            gtk_box_pack_start(GTK_BOX(row), instr, FALSE, FALSE, 5);
            gtk_box_pack_start(GTK_BOX(row), wait, FALSE, FALSE, 5);
            
            gtk_list_box_insert(ready_box, row, -1);
        }
    }
    gtk_widget_show_all(ready_queue);

    // Update blocked queue
    GtkListBox *blocked_box = GTK_LIST_BOX(blocked_queue);
    children = gtk_container_get_children(GTK_CONTAINER(blocked_queue));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);

    // Add header to blocked queue
    GtkWidget *blocked_header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    pid_label = gtk_label_new("PID");
    pc_label = gtk_label_new("PC");
    instr_label = gtk_label_new("Instruction");
    GtkWidget *block_label = gtk_label_new("Block Time");

    gtk_widget_set_size_request(pid_label, 60, -1);
    gtk_widget_set_size_request(pc_label, 80, -1);
    gtk_widget_set_size_request(instr_label, 150, -1);
    gtk_widget_set_size_request(block_label, 80, -1);

    gtk_label_set_xalign(GTK_LABEL(pid_label), 0.5);
    gtk_label_set_xalign(GTK_LABEL(pc_label), 0.5);
    gtk_label_set_xalign(GTK_LABEL(instr_label), 0.5);
    gtk_label_set_xalign(GTK_LABEL(block_label), 0.5);

    gtk_box_pack_start(GTK_BOX(blocked_header), pid_label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(blocked_header), pc_label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(blocked_header), instr_label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(blocked_header), block_label, FALSE, FALSE, 5);

    gtk_list_box_insert(blocked_box, blocked_header, -1);

    // Add blocked processes
    for (int i = 0; i < processCount; i++) {
        if (processes[i].state == BLOCKED) {
            GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
            
            // Get current instruction from memory
            const char* instruction = "Unknown";
            if (processes[i].programCounter <= processes[i].upperBound) {
                instruction = readFromMemory(processes[i].programCounter);
            }
            
            // Use tracked block time from PCB
            int block_time = processes[i].blockTime;
            
            // Create labels
            GtkWidget *pid = gtk_label_new(g_strdup_printf("%d", processes[i].pid));
            GtkWidget *pc = gtk_label_new(g_strdup_printf("0x%04X", processes[i].programCounter));
            GtkWidget *instr = gtk_label_new(instruction);
            GtkWidget *block = gtk_label_new(g_strdup_printf("%d", block_time));
            
            // Set sizes and alignment
            gtk_widget_set_size_request(pid, 60, -1);
            gtk_widget_set_size_request(pc, 80, -1);
            gtk_widget_set_size_request(instr, 150, -1);
            gtk_widget_set_size_request(block, 80, -1);
            
            gtk_label_set_xalign(GTK_LABEL(pid), 0.5);
            gtk_label_set_xalign(GTK_LABEL(pc), 0.5);
            gtk_label_set_xalign(GTK_LABEL(instr), 0.5);
            gtk_label_set_xalign(GTK_LABEL(block), 0.5);
            
            // Pack into row
            gtk_box_pack_start(GTK_BOX(row), pid, FALSE, FALSE, 5);
            gtk_box_pack_start(GTK_BOX(row), pc, FALSE, FALSE, 5);
            gtk_box_pack_start(GTK_BOX(row), instr, FALSE, FALSE, 5);
            gtk_box_pack_start(GTK_BOX(row), block, FALSE, FALSE, 5);
            
            gtk_list_box_insert(blocked_box, row, -1);
        }
    }
    gtk_widget_show_all(blocked_queue);

    // Update running process
    bool found = false;
    for (int i = 0; i < processCount; i++) {
        if (processes[i].state == RUNNING) {
            // Get current instruction from memory
            const char* instruction = "Unknown";
            if (processes[i].programCounter <= processes[i].upperBound) {
                instruction = readFromMemory(processes[i].programCounter);
            }
            
            // Create more detailed running process display
            char text[200];
            sprintf(text, "Running: PID %d (PC=0x%04X)\nInstruction: %s", 
                    processes[i].pid, processes[i].programCounter, instruction);
            gtk_label_set_text(GTK_LABEL(running_process_label), text);
            found = true;
            break;
        }
    }
    if (!found) {
        gtk_label_set_text(GTK_LABEL(running_process_label), "Running: None");
    }
    
    
    // Update resource status
    if (userInputMutex.ownerPID == -1) {
        gtk_label_set_text(GTK_LABEL(user_input_mutex), "User Input: Free");
    } else {
        char *text = g_strdup_printf("User Input: Held by PID %d", userInputMutex.ownerPID);
        gtk_label_set_text(GTK_LABEL(user_input_mutex), text);
        g_free(text);
    }
    
    if (userOutputMutex.ownerPID == -1) {
        gtk_label_set_text(GTK_LABEL(user_output_mutex), "User Output: Free");
    } else {
        char *text = g_strdup_printf("User Output: Held by PID %d", userOutputMutex.ownerPID);
        gtk_label_set_text(GTK_LABEL(user_output_mutex), text);
        g_free(text);
    }
    
    if (fileMutex.ownerPID == -1) {
        gtk_label_set_text(GTK_LABEL(file_mutex), "File: Free");
    } else {
        char *text = g_strdup_printf("File: Held by PID %d", fileMutex.ownerPID);
        gtk_label_set_text(GTK_LABEL(file_mutex), text);
        g_free(text);
    }
    
    // Update resource-specific blocked queues
    // User Input blocked queue
    children = gtk_container_get_children(GTK_CONTAINER(user_input_blocked));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    // Add header to user input blocked queue
    GtkWidget *input_header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    GtkWidget *pid_header = gtk_label_new("PID");
    GtkWidget *priority_header = gtk_label_new("Priority");
    GtkWidget *block_time_header = gtk_label_new("Block Time");
    
    gtk_widget_set_size_request(pid_header, 60, -1);
    gtk_widget_set_size_request(priority_header, 60, -1);
    gtk_widget_set_size_request(block_time_header, 80, -1);
    
    gtk_label_set_xalign(GTK_LABEL(pid_header), 0.5);
    gtk_label_set_xalign(GTK_LABEL(priority_header), 0.5);
    gtk_label_set_xalign(GTK_LABEL(block_time_header), 0.5);
    
    gtk_box_pack_start(GTK_BOX(input_header), pid_header, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(input_header), priority_header, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(input_header), block_time_header, FALSE, FALSE, 5);
    
    gtk_list_box_insert(GTK_LIST_BOX(user_input_blocked), input_header, -1);
    
    // Add processes waiting for user input
    WaitNode* node = userInputMutex.waitList;
    while (node) {
        GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
        
        // Create labels
        GtkWidget *pid = gtk_label_new(g_strdup_printf("%d", node->process->pid));
        GtkWidget *priority = gtk_label_new(g_strdup_printf("%d", node->process->priority));
        GtkWidget *block_time = gtk_label_new(g_strdup_printf("%d", node->process->blockTime));
        
        // Set sizes and alignment
        gtk_widget_set_size_request(pid, 60, -1);
        gtk_widget_set_size_request(priority, 60, -1);
        gtk_widget_set_size_request(block_time, 80, -1);
        
        gtk_label_set_xalign(GTK_LABEL(pid), 0.5);
        gtk_label_set_xalign(GTK_LABEL(priority), 0.5);
        gtk_label_set_xalign(GTK_LABEL(block_time), 0.5);
        
        // Pack into row
        gtk_box_pack_start(GTK_BOX(row), pid, FALSE, FALSE, 5);
        gtk_box_pack_start(GTK_BOX(row), priority, FALSE, FALSE, 5);
        gtk_box_pack_start(GTK_BOX(row), block_time, FALSE, FALSE, 5);
        
        gtk_list_box_insert(GTK_LIST_BOX(user_input_blocked), row, -1);
        node = node->next;
    }
    gtk_widget_show_all(user_input_blocked);
    
    // User Output blocked queue
    children = gtk_container_get_children(GTK_CONTAINER(user_output_blocked));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    // Add header to user output blocked queue
    GtkWidget *output_header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    pid_header = gtk_label_new("PID");
    priority_header = gtk_label_new("Priority");
    block_time_header = gtk_label_new("Block Time");
    
    gtk_widget_set_size_request(pid_header, 60, -1);
    gtk_widget_set_size_request(priority_header, 60, -1);
    gtk_widget_set_size_request(block_time_header, 80, -1);
    
    gtk_label_set_xalign(GTK_LABEL(pid_header), 0.5);
    gtk_label_set_xalign(GTK_LABEL(priority_header), 0.5);
    gtk_label_set_xalign(GTK_LABEL(block_time_header), 0.5);
    
    gtk_box_pack_start(GTK_BOX(output_header), pid_header, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(output_header), priority_header, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(output_header), block_time_header, FALSE, FALSE, 5);
    
    gtk_list_box_insert(GTK_LIST_BOX(user_output_blocked), output_header, -1);
    
    // Add processes waiting for user output
    node = userOutputMutex.waitList;
    while (node) {
        GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
        
        // Create labels
        GtkWidget *pid = gtk_label_new(g_strdup_printf("%d", node->process->pid));
        GtkWidget *priority = gtk_label_new(g_strdup_printf("%d", node->process->priority));
        GtkWidget *block_time = gtk_label_new(g_strdup_printf("%d", node->process->blockTime));
        
        // Set sizes and alignment
        gtk_widget_set_size_request(pid, 60, -1);
        gtk_widget_set_size_request(priority, 60, -1);
        gtk_widget_set_size_request(block_time, 80, -1);
        
        gtk_label_set_xalign(GTK_LABEL(pid), 0.5);
        gtk_label_set_xalign(GTK_LABEL(priority), 0.5);
        gtk_label_set_xalign(GTK_LABEL(block_time), 0.5);
        
        // Pack into row
        gtk_box_pack_start(GTK_BOX(row), pid, FALSE, FALSE, 5);
        gtk_box_pack_start(GTK_BOX(row), priority, FALSE, FALSE, 5);
        gtk_box_pack_start(GTK_BOX(row), block_time, FALSE, FALSE, 5);
        
        gtk_list_box_insert(GTK_LIST_BOX(user_output_blocked), row, -1);
        node = node->next;
    }
    gtk_widget_show_all(user_output_blocked);
    
    // File blocked queue
    children = gtk_container_get_children(GTK_CONTAINER(file_blocked));
    g_list_free_full(children, (GDestroyNotify)gtk_widget_destroy);
    
    // Add header to file blocked queue
    GtkWidget *file_header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    pid_header = gtk_label_new("PID");
    priority_header = gtk_label_new("Priority");
    block_time_header = gtk_label_new("Block Time");
    
    gtk_widget_set_size_request(pid_header, 60, -1);
    gtk_widget_set_size_request(priority_header, 60, -1);
    gtk_widget_set_size_request(block_time_header, 80, -1);
    
    gtk_label_set_xalign(GTK_LABEL(pid_header), 0.5);
    gtk_label_set_xalign(GTK_LABEL(priority_header), 0.5);
    gtk_label_set_xalign(GTK_LABEL(block_time_header), 0.5);
    
    gtk_box_pack_start(GTK_BOX(file_header), pid_header, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(file_header), priority_header, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(file_header), block_time_header, FALSE, FALSE, 5);
    
    gtk_list_box_insert(GTK_LIST_BOX(file_blocked), file_header, -1);
    
    // Add processes waiting for file access
    node = fileMutex.waitList;
    while (node) {
        GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
        
        // Create labels
        GtkWidget *pid = gtk_label_new(g_strdup_printf("%d", node->process->pid));
        GtkWidget *priority = gtk_label_new(g_strdup_printf("%d", node->process->priority));
        GtkWidget *block_time = gtk_label_new(g_strdup_printf("%d", node->process->blockTime));
        
        // Set sizes and alignment
        gtk_widget_set_size_request(pid, 60, -1);
        gtk_widget_set_size_request(priority, 60, -1);
        gtk_widget_set_size_request(block_time, 80, -1);
        
        gtk_label_set_xalign(GTK_LABEL(pid), 0.5);
        gtk_label_set_xalign(GTK_LABEL(priority), 0.5);
        gtk_label_set_xalign(GTK_LABEL(block_time), 0.5);
        
        // Pack into row
        gtk_box_pack_start(GTK_BOX(row), pid, FALSE, FALSE, 5);
        gtk_box_pack_start(GTK_BOX(row), priority, FALSE, FALSE, 5);
        gtk_box_pack_start(GTK_BOX(row), block_time, FALSE, FALSE, 5);
        
        gtk_list_box_insert(GTK_LIST_BOX(file_blocked), row, -1);
        node = node->next;
    }
    gtk_widget_show_all(file_blocked);
    
    // Highlight the input section if we're waiting for input
    if (waitingForInput) {
        // Find process that is waiting for input and show its instruction
        for (int i = 0; i < processCount; i++) {
            if (processes[i].pid == processWaitingForInput) {
                const char* instruction = "Unknown";
                if (processes[i].programCounter <= processes[i].upperBound) {
                    instruction = readFromMemory(processes[i].programCounter);
                }
                
                // Show instruction that needs input
                char msg[256];
                sprintf(msg, "Waiting for input: Process %d needs input for variable '%s'\nCurrent instruction: %s", 
                        processWaitingForInput, inputVariableName, instruction);
                
                // Create a highlighted background for send_input_btn
                GtkStyleContext *context = gtk_widget_get_style_context(send_input_btn);
                gtk_style_context_add_class(context, "suggested-action");
                gtk_button_set_label(GTK_BUTTON(send_input_btn), "Send Input (Required)");
                
                add_event_gui_message(msg);
                break;
            }
        }
    } else {
        // Remove highlighting if not waiting for input
        GtkStyleContext *context = gtk_widget_get_style_context(send_input_btn);
        gtk_style_context_remove_class(context, "suggested-action");
        gtk_button_set_label(GTK_BUTTON(send_input_btn), "Send Input");
    }
}

// UI Creation helper functions
GtkWidget* create_scrolled(GtkWidget *child) {
    GtkWidget *scrolled = gtk_scrolled_window_new(NULL, NULL);  // Create scrolled window
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_container_add(GTK_CONTAINER(scrolled), child);  // Add the child widget
    return scrolled;  // Return the scrolled window
}

GtkWidget* create_process_table() {
    GtkWidget *table = gtk_list_box_new();
    gtk_widget_set_hexpand(table, TRUE);
    gtk_widget_set_vexpand(table, TRUE);

    // Create header row
    GtkWidget *header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_widget_set_margin_start(header, 5);
    gtk_widget_set_margin_end(header, 5);
    gtk_widget_set_margin_top(header, 5);
    
    // Define column widths
    const int column_widths[] = {100, 100, 100, 100, 100}; // Adjust these widths as needed
    const char *column_titles[] = {"Process ID", "State", "Priority", "PC", "Memory"};
    
    for (int i = 0; i < 5; i++) {
        GtkWidget *label = gtk_label_new(column_titles[i]);
        gtk_widget_set_size_request(label, column_widths[i], -1);
        gtk_label_set_xalign(GTK_LABEL(label), 0.5); // Center align text
        gtk_box_pack_start(GTK_BOX(header), label, FALSE, FALSE, 0);
    }
    
    gtk_list_box_insert(GTK_LIST_BOX(table), header, 0);

    return table;
}

GtkWidget* create_memory_grid() {
    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_homogeneous(GTK_GRID(grid), TRUE);
    gtk_grid_set_column_homogeneous(GTK_GRID(grid), TRUE);

    for (int i = 0; i < 60; i++) {
        memory_labels[i] = gtk_label_new("Empty");
        gtk_widget_set_halign(memory_labels[i], GTK_ALIGN_CENTER);
        gtk_widget_set_valign(memory_labels[i], GTK_ALIGN_CENTER);
        gtk_grid_attach(GTK_GRID(grid), memory_labels[i], i % 10, i / 10, 1, 1);
    }

    return create_scrolled(grid);
}

void build_main_window();

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);
    // Connect logger hooks after GTK initialization
    add_log_gui_message = gui_log_message;
    add_event_gui_message = gui_event_message;

    // 1. Create main window
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "OS Scheduler Simulation");
    gtk_window_set_default_size(GTK_WINDOW(window), 1200, 700);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // 2. Create main layout
    GtkWidget *main_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), main_box);
    
    // 3. Create header with title
    GtkWidget *header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_pack_start(GTK_BOX(main_box), header, FALSE, FALSE, 5);
    
    GtkWidget *title_label = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(title_label), "<span size='x-large' weight='bold'>Operating System Scheduler Simulation</span>");
    gtk_box_pack_start(GTK_BOX(header), title_label, TRUE, TRUE, 0);
    
    // 4. Create main content area (2 columns)
    GtkWidget *content = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_pack_start(GTK_BOX(main_box), content, TRUE, TRUE, 0);
    
    // Left column (controls + overview)
    GtkWidget *left_column = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_box_pack_start(GTK_BOX(content), left_column, FALSE, FALSE, 5);
    
    // Overview section
    GtkWidget *overview_frame = gtk_frame_new("System Overview");
    gtk_box_pack_start(GTK_BOX(left_column), overview_frame, FALSE, FALSE, 0);
    
    overview_label = gtk_label_new("System Overview\nTotal Processes: 0\nClock Cycle: 0\nAlgorithm: None");
    gtk_container_add(GTK_CONTAINER(overview_frame), overview_label);
    
    // Control panel
    GtkWidget *control_frame = gtk_frame_new("Scheduler Control");
    gtk_box_pack_start(GTK_BOX(left_column), control_frame, FALSE, FALSE, 0);
    
    GtkWidget *control_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(control_frame), control_box);
    
    // Algorithm selection
    GtkWidget *algo_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(control_box), algo_box, FALSE, FALSE, 5);
    
    gtk_box_pack_start(GTK_BOX(algo_box), gtk_label_new("Algorithm:"), FALSE, FALSE, 5);
    algorithm_dropdown = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algorithm_dropdown), "First Come First Serve");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algorithm_dropdown), "Round Robin");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algorithm_dropdown), "Multi-Level Feedback Queue");
    gtk_combo_box_set_active(GTK_COMBO_BOX(algorithm_dropdown), 0);
    gtk_box_pack_start(GTK_BOX(algo_box), algorithm_dropdown, TRUE, TRUE, 5);
    g_signal_connect(algorithm_dropdown, "changed", G_CALLBACK(on_algorithm_changed), NULL);
    
    // Quantum setting (only for Round Robin)
    GtkWidget *quantum_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(control_box), quantum_box, FALSE, FALSE, 5);

    gtk_box_pack_start(GTK_BOX(quantum_box), gtk_label_new("Quantum:"), FALSE, FALSE, 5);
    quantum_field = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(quantum_field), "3");  // Default quantum
    gtk_widget_set_sensitive(quantum_field, FALSE);  // Disable by default
    gtk_box_pack_start(GTK_BOX(quantum_box), quantum_field, TRUE, TRUE, 5);

    // Connect quantum field change handler
    g_signal_connect(quantum_field, "changed", G_CALLBACK(on_quantum_changed), NULL);
    
    // Control buttons
    GtkWidget *button_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(control_box), button_box, FALSE, FALSE, 5);
    
    start_btn = gtk_button_new_with_label("Start");
    stop_btn = gtk_button_new_with_label("Stop");
    reset_btn = gtk_button_new_with_label("Reset");
    step_btn = gtk_button_new_with_label("Step");
    auto_btn = gtk_button_new_with_label("Auto");
    
    gtk_box_pack_start(GTK_BOX(button_box), start_btn, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(button_box), stop_btn, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(button_box), reset_btn, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(button_box), step_btn, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(button_box), auto_btn, TRUE, TRUE, 5);
    
    g_signal_connect(start_btn, "clicked", G_CALLBACK(on_start_clicked), NULL);
    g_signal_connect(stop_btn, "clicked", G_CALLBACK(on_stop_clicked), NULL);
    g_signal_connect(reset_btn, "clicked", G_CALLBACK(on_reset_clicked), NULL);
    g_signal_connect(step_btn, "clicked", G_CALLBACK(on_step_clicked), NULL);
    g_signal_connect(auto_btn, "clicked", G_CALLBACK(on_auto_clicked), NULL);
    
    // Process creation
    GtkWidget *process_frame = gtk_frame_new("Add Process");
    gtk_box_pack_start(GTK_BOX(left_column), process_frame, FALSE, FALSE, 0);
    
    GtkWidget *process_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(process_frame), process_box);
    
    // Arrival time
    GtkWidget *arrival_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(process_box), arrival_box, FALSE, FALSE, 5);
    
    gtk_box_pack_start(GTK_BOX(arrival_box), gtk_label_new("Arrival Time:"), FALSE, FALSE, 5);
    arrival_time_entry = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(arrival_time_entry), "0");
    gtk_box_pack_start(GTK_BOX(arrival_box), arrival_time_entry, TRUE, TRUE, 5);
    
    // Input A and B for program parameters
    GtkWidget *input_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(process_box), input_box, FALSE, FALSE, 5);
    
    gtk_box_pack_start(GTK_BOX(input_box), gtk_label_new("Input A:"), FALSE, FALSE, 5);
    input_a_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(input_box), input_a_entry, TRUE, TRUE, 5);
    
    gtk_box_pack_start(GTK_BOX(input_box), gtk_label_new("Input B:"), FALSE, FALSE, 5);
    input_b_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(input_box), input_b_entry, TRUE, TRUE, 5);
    
    // Add process button
    GtkWidget *add_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(process_box), add_box, FALSE, FALSE, 5);
    
    add_process_btn = gtk_button_new_with_label("Add Process");
    send_input_btn = gtk_button_new_with_label("Send Inputs");
    
    gtk_box_pack_start(GTK_BOX(add_box), add_process_btn, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(add_box), send_input_btn, TRUE, TRUE, 5);
    
    g_signal_connect(add_process_btn, "clicked", G_CALLBACK(on_add_process_clicked), NULL);
    g_signal_connect(send_input_btn, "clicked", G_CALLBACK(on_send_input_clicked), NULL);
    
    // Resource status
    GtkWidget *resource_frame = gtk_frame_new("Resource Status");
    gtk_box_pack_start(GTK_BOX(left_column), resource_frame, FALSE, FALSE, 0);
    
    GtkWidget *resource_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 1);
    gtk_container_add(GTK_CONTAINER(resource_frame), resource_box);
    
    user_input_mutex = gtk_label_new("User Input: Free");
    user_output_mutex = gtk_label_new("User Output: Free");
    file_mutex = gtk_label_new("File: Free");
  // Add resource mutex indicators
  gtk_box_pack_start(GTK_BOX(resource_box), user_input_mutex, FALSE, FALSE, 1);
  gtk_box_pack_start(GTK_BOX(resource_box), user_output_mutex, FALSE, FALSE, 1);
  gtk_box_pack_start(GTK_BOX(resource_box), file_mutex, FALSE, FALSE, 1);

// User Input Blocked
gtk_box_pack_start(GTK_BOX(resource_box), gtk_label_new("Processes Waiting for User Input:"), FALSE, FALSE, 1);
user_input_blocked = gtk_list_box_new();
gtk_widget_set_size_request(user_input_blocked, -1, 50);
gtk_widget_set_vexpand(user_input_blocked, FALSE);
gtk_box_pack_start(GTK_BOX(resource_box), create_scrolled(user_input_blocked), FALSE, FALSE, 5);

// User Output Blocked
gtk_box_pack_start(GTK_BOX(resource_box), gtk_label_new("Processes Waiting for User Output:"), FALSE, FALSE, 1);
user_output_blocked = gtk_list_box_new();
gtk_widget_set_size_request(user_output_blocked, -1, 50);
gtk_widget_set_vexpand(user_output_blocked, FALSE);
gtk_box_pack_start(GTK_BOX(resource_box), create_scrolled(user_output_blocked), FALSE, FALSE, 5);

// File Blocked
gtk_box_pack_start(GTK_BOX(resource_box), gtk_label_new("Processes Waiting for File Access:"), FALSE, FALSE, 1);
file_blocked = gtk_list_box_new();
gtk_widget_set_size_request(file_blocked, -1, 50);
gtk_widget_set_vexpand(file_blocked, FALSE);
gtk_box_pack_start(GTK_BOX(resource_box), create_scrolled(file_blocked), FALSE, FALSE, 5);
    
    // Right column (process table, queues, memory)
    GtkWidget *right_column = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_box_pack_start(GTK_BOX(content), right_column, TRUE, TRUE, 5);
    
    // Process table
    GtkWidget *process_table_frame = gtk_frame_new("Process Table");
    gtk_box_pack_start(GTK_BOX(right_column), process_table_frame, TRUE, TRUE, 0);
    
    process_table = create_process_table();
    GtkWidget *process_scroll = create_scrolled(process_table);
    gtk_container_add(GTK_CONTAINER(process_table_frame), process_scroll);
    
    // Queues and running process
    GtkWidget *queue_frame = gtk_frame_new("Process Queues");
    gtk_box_pack_start(GTK_BOX(right_column), queue_frame, FALSE, FALSE, 0);
    
    GtkWidget *queue_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_container_add(GTK_CONTAINER(queue_frame), queue_box);
    
    // Ready queue
    GtkWidget *ready_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_box_pack_start(GTK_BOX(queue_box), ready_box, TRUE, TRUE, 5);
    
    gtk_box_pack_start(GTK_BOX(ready_box), gtk_label_new("Ready Queue"), FALSE, FALSE, 0);
    ready_queue = gtk_list_box_new();
    gtk_box_pack_start(GTK_BOX(ready_box), create_scrolled(ready_queue), TRUE, TRUE, 5);
    
    // Running process
    GtkWidget *running_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_box_pack_start(GTK_BOX(queue_box), running_box, TRUE, TRUE, 5);
    
    gtk_box_pack_start(GTK_BOX(running_box), gtk_label_new("Running Process"), FALSE, FALSE, 0);
    running_process_label = gtk_label_new("Running: None");
    gtk_box_pack_start(GTK_BOX(running_box), running_process_label, TRUE, FALSE, 5);
    
    // Blocked queue
    GtkWidget *blocked_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_box_pack_start(GTK_BOX(queue_box), blocked_box, TRUE, TRUE, 5);
    
    gtk_box_pack_start(GTK_BOX(blocked_box), gtk_label_new("Blocked Queue"), FALSE, FALSE, 0);
    blocked_queue = gtk_list_box_new();
    gtk_box_pack_start(GTK_BOX(blocked_box), create_scrolled(blocked_queue), TRUE, TRUE, 5);
    
    // Memory viewer
    GtkWidget *memory_frame = gtk_frame_new("Memory Viewer");
    gtk_box_pack_start(GTK_BOX(right_column), memory_frame, TRUE, TRUE, 0);
    
    memory_grid = create_memory_grid();
    gtk_container_add(GTK_CONTAINER(memory_frame), memory_grid);
    
    // Logs
    GtkWidget *log_frame = gtk_frame_new("Logs & Console");
    gtk_box_pack_start(GTK_BOX(right_column), log_frame, TRUE, TRUE, 0);
    
    GtkWidget *log_notebook = gtk_notebook_new();
    gtk_container_add(GTK_CONTAINER(log_frame), log_notebook);
    
    log_textview = gtk_text_view_new();
    log_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(log_textview));
    gtk_text_view_set_editable(GTK_TEXT_VIEW(log_textview), FALSE);
    gtk_notebook_append_page(GTK_NOTEBOOK(log_notebook), create_scrolled(log_textview), gtk_label_new("Execution Log"));
    
    event_textview = gtk_text_view_new();
    event_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(event_textview));
    gtk_text_view_set_editable(GTK_TEXT_VIEW(event_textview), FALSE);
    gtk_notebook_append_page(GTK_NOTEBOOK(log_notebook), create_scrolled(event_textview), gtk_label_new("Events"));
    
    // Initialize backend components
    srand(time(NULL));
    // initializeMemory();
    // initializeQueues();
    add_event_message("OS Simulator initialized");
    
    // Show all and start main loop
    gtk_widget_show_all(window);
    gtk_main();
    
    return 0;
}
